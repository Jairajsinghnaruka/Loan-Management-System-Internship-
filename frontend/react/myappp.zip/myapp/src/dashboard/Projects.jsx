import { useState } from "react";

import "./Projects.css";

function Projects() {
  const [search, setSearch] = useState("");

  const projects = [
    {
      id: 1,
      name: "Loan Management System",
      manager: "John",
      status: "In Progress",
      progress: 75,
      team: 5,
    },
    {
      id: 2,
      name: "HR Portal",
      manager: "Sarah",
      status: "Completed",
      progress: 100,
      team: 3,
    },
    {
      id: 3,
      name: "CRM Dashboard",
      manager: "Mike",
      status: "Planning",
      progress: 10,
      team: 4,
    },
  ];

  return (
    <div className="projects-page">
      <div className="projects-header">
        <h1>Projects</h1>

        <button className="create-btn">
          + Create Project
        </button>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Projects</h3>
          <p>12</p>
        </div>

        <div className="stat-card">
          <h3>In Progress</h3>
          <p>5</p>
        </div>

        <div className="stat-card">
          <h3>Completed</h3>
          <p>4</p>
        </div>

        <div className="stat-card">
          <h3>Planning</h3>
          <p>3</p>
        </div>
      </div>

      <div className="toolbar">
        <input
          type="text"
          placeholder="Search Project..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select>
          <option>All Status</option>
          <option>Planning</option>
          <option>In Progress</option>
          <option>Completed</option>
        </select>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Project</th>
              <th>Manager</th>
              <th>Status</th>
              <th>Progress</th>
              <th>Team</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {projects
              .filter((project) =>
                project.name
                  .toLowerCase()
                  .includes(search.toLowerCase())
              )
              .map((project) => (
                <tr key={project.id}>
                  <td>{project.name}</td>
                  <td>{project.manager}</td>
                  <td>{project.status}</td>

                  <td>
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{
                          width: `${project.progress}%`,
                        }}
                      ></div>
                    </div>

                    {project.progress}%
                  </td>

                  <td>{project.team}</td>

                  <td>
                    <button className="view-btn">
                      View
                    </button>

                    <button className="edit-btn">
                      Edit
                    </button>

                    <button className="delete-btn">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Projects;