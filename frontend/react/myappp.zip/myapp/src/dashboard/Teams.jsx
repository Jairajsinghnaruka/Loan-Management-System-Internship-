import { useState } from "react";
import "./Teams.css";

function Teams() {
  const [search, setSearch] = useState("");

  const members = [
    {
      id: 1,
      name: "John Doe",
      role: "Frontend Developer",
      team: "Frontend",
      email: "john@company.com",
      status: "Active",
    },
    {
      id: 2,
      name: "Sarah Smith",
      role: "Backend Developer",
      team: "Backend",
      email: "sarah@company.com",
      status: "Active",
    },
    {
      id: 3,
      name: "Mike Johnson",
      role: "UI Designer",
      team: "Design",
      email: "mike@company.com",
      status: "Inactive",
    },
    {
      id: 4,
      name: "Emma Brown",
      role: "Project Manager",
      team: "Management",
      email: "emma@company.com",
      status: "Active",
    },
  ];

  return (
    <div className="teams-page">

      <div className="teams-header">
        <h1>Teams Management</h1>

        <button className="add-member-btn">
          Add Member
        </button>
      </div>

      <div className="team-stats">

        <div className="stat-card">
          <h3>Total Teams</h3>
          <p>4</p>
        </div>

        <div className="stat-card">
          <h3>Total Employees</h3>
          <p>25</p>
        </div>

        <div className="stat-card">
          <h3>Active Members</h3>
          <p>20</p>
        </div>

        <div className="stat-card">
          <h3>Team Leads</h3>
          <p>4</p>
        </div>

      </div>

      <div className="search-section">
        <input
          type="text"
          placeholder="Search Member..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="members-grid">

        {members
          .filter((member) =>
            member.name
              .toLowerCase()
              .includes(search.toLowerCase())
          )
          .map((member) => (
            <div className="member-card" key={member.id}>

              <h2>{member.name}</h2>

              <p>
                <strong>Role:</strong> {member.role}
              </p>

              <p>
                <strong>Team:</strong> {member.team}
              </p>

              <p>
                <strong>Email:</strong> {member.email}
              </p>

              <p>
                <strong>Status:</strong> {member.status}
              </p>

              <div className="member-actions">
                <button className="edit-btn">
                  Edit
                </button>

                <button className="delete-btn">
                  Remove
                </button>
              </div>

            </div>
          ))}

      </div>

    </div>
  );
}

export default Teams;