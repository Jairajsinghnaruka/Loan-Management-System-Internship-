import { useState } from "react";
import "./Calendar.css";

function Calendar() {
  const [selectedDate, setSelectedDate] = useState("");

  const events = [
    {
      id: 1,
      title: "Project Review Meeting",
      date: "2026-06-10",
      time: "10:00 AM",
    },
    {
      id: 2,
      title: "Client Presentation",
      date: "2026-06-15",
      time: "02:00 PM",
    },
    {
      id: 3,
      title: "Team Standup",
      date: "2026-06-20",
      time: "09:00 AM",
    },
    {
      id: 4,
      title: "Sprint Planning",
      date: "2026-06-25",
      time: "11:00 AM",
    },
  ];

  return (
    <div className="calendar-page">

      <div className="calendar-header">
        <h1>📅 Calendar</h1>

        <button className="add-event-btn">
          + Add Event
        </button>
      </div>

      <div className="calendar-top">

        <div className="calendar-picker">
          <h3>Select Date</h3>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) =>
              setSelectedDate(e.target.value)
            }
          />
        </div>

        <div className="calendar-summary">
          <div className="summary-card">
            <h3>Total Events</h3>
            <p>{events.length}</p>
          </div>

          <div className="summary-card">
            <h3>Meetings</h3>
            <p>2</p>
          </div>

          <div className="summary-card">
            <h3>Deadlines</h3>
            <p>1</p>
          </div>
        </div>

      </div>

      <h2 className="events-title">
        Upcoming Events
      </h2>

      <div className="events-grid">
        {events
          .filter(
            (event) =>
              !selectedDate ||
              event.date === selectedDate
          )
          .map((event) => (
            <div
              className="event-card"
              key={event.id}
            >
              <h3>{event.title}</h3>

              <p>
                <strong>Date:</strong> {event.date}
              </p>

              <p>
                <strong>Time:</strong> {event.time}
              </p>

              <button className="view-btn">
                View Details
              </button>
            </div>
          ))}
      </div>

    </div>
  );
}

export default Calendar;