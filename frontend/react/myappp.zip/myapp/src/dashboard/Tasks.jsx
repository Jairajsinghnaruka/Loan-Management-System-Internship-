import "./Tasks.css";

function Tasks() {
  const tasks = [
    {
      id: 1,
      title: "Create Login Page",
      project: "Loan Management System",
      assignedTo: "John",
      priority: "High",
      status: "In Progress",
    },
    {
      id: 2,
      title: "Design Dashboard",
      project: "CRM Dashboard",
      assignedTo: "Sarah",
      priority: "Medium",
      status: "Pending",
    },
    {
      id: 3,
      title: "Database Setup",
      project: "HR Portal",
      assignedTo: "Mike",
      priority: "High",
      status: "Completed",
    },
  ];

  return (
    <div className="tasks-page">
      <div className="tasks-header">
        <h1>Tasks</h1>

        <button className="add-task-btn">
          + Create Task
        </button>
      </div>

      <div className="task-stats">
        <div className="task-card">
          <h3>Total Tasks</h3>
          <p>25</p>
        </div>

        <div className="task-card">
          <h3>Pending</h3>
          <p>8</p>
        </div>

        <div className="task-card">
          <h3>In Progress</h3>
          <p>12</p>
        </div>

        <div className="task-card">
          <h3>Completed</h3>
          <p>5</p>
        </div>
      </div>

      <div className="task-filters">
        <input
          type="text"
          placeholder="Search Tasks..."
        />

        <select>
          <option>All Status</option>
          <option>Pending</option>
          <option>In Progress</option>
          <option>Completed</option>
        </select>

        <select>
          <option>All Priority</option>
          <option>High</option>
          <option>Medium</option>
          <option>Low</option>
        </select>
      </div>

      <div className="task-table">
        <div className="table-header">
          <div>Task</div>
          <div>Project</div>
          <div>Assigned To</div>
          <div>Priority</div>
          <div>Status</div>
          <div>Actions</div>
        </div>

        {tasks.map((task) => (
          <div className="table-row" key={task.id}>
            <div>{task.title}</div>
            <div>{task.project}</div>
            <div>{task.assignedTo}</div>
            <div>{task.priority}</div>
            <div>{task.status}</div>

            <div className="actions">
              <button className="view-btn">
                View
              </button>

              <button className="edit-btn">
                Edit
              </button>

              <button className="delete-btn">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Tasks;