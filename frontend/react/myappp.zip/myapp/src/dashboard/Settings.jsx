import "./Settings.css";

function Settings() {
  return (
    <div className="settings-page">
      <h1>⚙️ Settings</h1>

      <div className="settings-grid">

        <div className="settings-card">
          <h3>👤 Profile Settings</h3>
          <input type="text" placeholder="Full Name" />
          <input type="email" placeholder="Email Address" />
          <button>Save Changes</button>
        </div>

        <div className="settings-card">
          <h3>🔒 Security</h3>
          <input type="password" placeholder="Current Password" />
          <input type="password" placeholder="New Password" />
          <button>Update Password</button>
        </div>

        <div className="settings-card">
          <h3>🔔 Notifications</h3>

          <label>
            <input type="checkbox" />
            Email Notifications
          </label>

          <label>
            <input type="checkbox" />
            Project Updates
          </label>

          <label>
            <input type="checkbox" />
            Team Alerts
          </label>

          <button>Save Preferences</button>
        </div>

        <div className="settings-card">
          <h3>🎨 Appearance</h3>

          <select>
            <option>Light Mode</option>
            <option>Dark Mode</option>
          </select>

          <button>Apply Theme</button>
        </div>

      </div>
    </div>
  );
}

export default Settings;